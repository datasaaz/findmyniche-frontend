
  # FindMyNiche - Coming Soon

  This is a code bundle for FindMyNiche - Coming Soon. The original project is available at https://www.figma.com/design/EiqgoFEeRvgoZjIwqRBvlC/FindMyNiche---Coming-Soon.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  